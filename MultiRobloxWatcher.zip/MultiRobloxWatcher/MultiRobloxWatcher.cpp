/*
 * MultiRobloxWatcher
 * -------------------
 * Tray-icon background watcher that lets multiple ROBLOX instances run.
 *
 * Newer ROBLOX builds no longer rely solely on a named Mutex
 * ("ROBLOX_singletonMutex") to prevent a second instance - they also use a
 * named Event object ("...\BaseNamedObjects\ROBLOX_singletonEvent"). Simply
 * opening-and-closing our own handle to that event does nothing, because the
 * object stays alive until EVERY handle to it (including the one Roblox
 * itself holds) is closed.
 *
 * So instead, this watcher:
 *   1. Every 2 seconds, cheaply checks whether RobloxPlayerBeta.exe is running
 *      (CreateToolhelp32Snapshot - negligible CPU cost).
 *   2. The FIRST time it sees a new Roblox PID, it enumerates that process's
 *      open handles (NtQuerySystemInformation), finds the Event object whose
 *      name ends in "ROBLOX_singletonEvent", and force-closes it inside
 *      Roblox's own process via DuplicateHandle(..., DUPLICATE_CLOSE_SOURCE).
 *      This is the same technique Sysinternals' handle.exe -c uses.
 *   3. If that fails, it tries again on the NEXT 2-second tick. If it fails a
 *      second time in a row, it shows a tray balloon notification saying so.
 *   4. Either way (success or gave-up-failure), it then goes quiet and does
 *      NOT touch the handle again - even if you open more Roblox windows -
 *      until every single RobloxPlayerBeta.exe process has closed. Once none
 *      are left running, it resets and starts watching for the next launch.
 *      The expensive handle scan only ever runs right at the start of a
 *      "Roblox session"; the recurring 2-second check is just the cheap
 *      process-list lookup.
 *
 * Tray menu:
 *   - Enable/Disable checking  (pauses/resumes step 1-3 above)
 *   - Exit
 *
 * The app also registers itself to run at Windows startup
 * (HKCU\Software\Microsoft\Windows\CurrentVersion\Run).
 *
 * BUILD (Visual Studio):
 *   1. Create a new "Windows Desktop Application" (Win32) C++ project.
 *   2. Replace its generated .cpp with this file.
 *   3. Project Properties -> Linker -> System -> SubSystem: Windows.
 *   4. Project Properties -> Linker -> Input -> Additional Dependencies, add:
 *        Shell32.lib;Advapi32.lib;User32.lib;Gdi32.lib
 *      (these are already in the default Win32 template's dependencies)
 *   5. Character Set: "Use Unicode Character Set".
 *   6. Build (x64, Release). No admin rights are required to run it, unless
 *      Roblox itself is somehow running elevated (uncommon).
 *
 * NOTE: This only manipulates a kernel object inside your own local Roblox
 * process on your own machine - it does not touch the network, other users,
 * or Roblox's servers.
 */

#include <Windows.h>
#include <TlHelp32.h>
#include <shellapi.h>
#include <string>
#include <vector>
#include "resource.h" // IDI_TRAYICON - add app.rc + resource.h to the project

#pragma comment(lib, "Shell32.lib")
#pragma comment(lib, "Advapi32.lib")
#pragma comment(lib, "User32.lib")

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------
static const wchar_t* kProcessName      = L"RobloxPlayerBeta.exe";
static const wchar_t* kHandleNameSuffix = L"ROBLOX_singletonEvent";
static const UINT     kCheckIntervalMs  = 2000;
static const wchar_t* kAppName          = L"MultiRobloxWatcher";
static const wchar_t* kWindowClassName  = L"MultiRobloxWatcherWndClass";

// ---------------------------------------------------------------------------
// Minimal NT internals (there's no public header for these - declared by hand)
// ---------------------------------------------------------------------------
typedef LONG NTSTATUS;

typedef struct _UNICODE_STRING_LOCAL {
    USHORT Length;
    USHORT MaximumLength;
    PWSTR  Buffer;
} UNICODE_STRING_LOCAL;

typedef struct _OBJECT_TYPE_INFORMATION_LOCAL {
    UNICODE_STRING_LOCAL TypeName;
    BYTE Reserved[0x200]; // don't care about the rest of the (large) struct
} OBJECT_TYPE_INFORMATION_LOCAL;

typedef struct _OBJECT_NAME_INFORMATION_LOCAL {
    UNICODE_STRING_LOCAL Name;
} OBJECT_NAME_INFORMATION_LOCAL;

typedef struct _SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX_LOCAL {
    PVOID     Object;
    ULONG_PTR UniqueProcessId;
    ULONG_PTR HandleValue;
    ULONG     GrantedAccess;
    USHORT    CreatorBackTraceIndex;
    USHORT    ObjectTypeIndex;
    ULONG     HandleAttributes;
    ULONG     Reserved;
} SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX_LOCAL;

typedef struct _SYSTEM_HANDLE_INFORMATION_EX_LOCAL {
    ULONG_PTR NumberOfHandles;
    ULONG_PTR Reserved;
    SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX_LOCAL Handles[1];
} SYSTEM_HANDLE_INFORMATION_EX_LOCAL;

typedef NTSTATUS(NTAPI* PFN_NtQuerySystemInformation)(
    ULONG SystemInformationClass,
    PVOID SystemInformation,
    ULONG SystemInformationLength,
    PULONG ReturnLength);

typedef NTSTATUS(NTAPI* PFN_NtQueryObject)(
    HANDLE Handle,
    ULONG ObjectInformationClass,
    PVOID ObjectInformation,
    ULONG ObjectInformationLength,
    PULONG ReturnLength);

static const ULONG SystemExtendedHandleInformation_Local = 64;
static const ULONG ObjectNameInformation_Local           = 1;
static const ULONG ObjectTypeInformation_Local           = 2;
static const NTSTATUS STATUS_INFO_LENGTH_MISMATCH_LOCAL  = (NTSTATUS)0xC0000004L;

// ---------------------------------------------------------------------------
// Global state
// ---------------------------------------------------------------------------
static NOTIFYICONDATAW g_nid = {};
static bool            g_enabled            = true;
static bool            g_handledThisSession = false; // already dealt with the singleton event for the currently-open Roblox run(s)
static int             g_failCount          = 0;
static ULONGLONG       g_firstDetectedTick  = 0;      // 0 = not currently waiting on a fresh detection
static const ULONGLONG kCloseDelayMs        = 4000;   // wait this long after first seeing Roblox before attempting the close

static const UINT WM_TRAYICON  = WM_APP + 1;
static const UINT ID_TIMER     = 1;
static const UINT ID_TOGGLE    = 1001;
static const UINT ID_EXIT      = 1002;

// ---------------------------------------------------------------------------
// Find a running process by exe name. Returns true and sets outPid if found.
// ---------------------------------------------------------------------------
static bool FindProcessByName(const wchar_t* exeName, DWORD& outPid)
{
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return false;

    PROCESSENTRY32W pe = {};
    pe.dwSize = sizeof(pe);
    bool found = false;

    if (Process32FirstW(snap, &pe)) {
        do {
            if (_wcsicmp(pe.szExeFile, exeName) == 0) {
                outPid = pe.th32ProcessID;
                found = true;
                break;
            }
        } while (Process32NextW(snap, &pe));
    }

    CloseHandle(snap);
    return found;
}

// ---------------------------------------------------------------------------
// Enumerate handles owned by targetPid, find the Event object whose name
// ends with nameSuffix, and force-close it inside that process.
// Returns true if the handle was found and successfully closed.
// ---------------------------------------------------------------------------
static bool CloseHandleByNameInProcess(DWORD targetPid, const std::wstring& nameSuffix)
{
    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    if (!ntdll) return false;

    auto NtQuerySystemInformation =
        (PFN_NtQuerySystemInformation)GetProcAddress(ntdll, "NtQuerySystemInformation");
    auto NtQueryObject =
        (PFN_NtQueryObject)GetProcAddress(ntdll, "NtQueryObject");
    if (!NtQuerySystemInformation || !NtQueryObject) return false;

    // Grow a buffer until NtQuerySystemInformation succeeds.
    ULONG bufSize = 1 << 16; // start at 64 KB
    std::vector<BYTE> buffer(bufSize);
    NTSTATUS status;
    ULONG returnLen = 0;

    for (int attempt = 0; attempt < 8; ++attempt) {
        status = NtQuerySystemInformation(SystemExtendedHandleInformation_Local,
                                           buffer.data(), bufSize, &returnLen);
        if (status == 0) break;
        if (status == STATUS_INFO_LENGTH_MISMATCH_LOCAL) {
            bufSize = returnLen > bufSize ? returnLen + (1 << 16) : bufSize * 2;
            buffer.assign(bufSize, 0);
            continue;
        }
        return false; // unexpected failure
    }
    if (status != 0) return false;

    auto* info = reinterpret_cast<SYSTEM_HANDLE_INFORMATION_EX_LOCAL*>(buffer.data());
    bool closed = false;

    HANDLE hTargetProcess = OpenProcess(PROCESS_DUP_HANDLE | PROCESS_QUERY_LIMITED_INFORMATION,
                                         FALSE, targetPid);
    if (!hTargetProcess) return false; // e.g. Roblox running elevated & we're not

    for (ULONG_PTR i = 0; i < info->NumberOfHandles && !closed; ++i) {
        const auto& entry = info->Handles[i];
        if ((DWORD)entry.UniqueProcessId != targetPid) continue;

        HANDLE hInspect = NULL;
        if (!DuplicateHandle(hTargetProcess, (HANDLE)entry.HandleValue,
                              GetCurrentProcess(), &hInspect,
                              0, FALSE, DUPLICATE_SAME_ACCESS)) {
            continue; // handle not duplicable (rare) - skip it
        }

        // Cheap type check first (safe/fast for every object type).
        BYTE typeBuf[0x400];
        ULONG typeLen = 0;
        bool isEvent = false;
        if (NtQueryObject(hInspect, ObjectTypeInformation_Local, typeBuf, sizeof(typeBuf), &typeLen) == 0) {
            auto* typeInfo = reinterpret_cast<OBJECT_TYPE_INFORMATION_LOCAL*>(typeBuf);
            if (typeInfo->TypeName.Buffer && typeInfo->TypeName.Length > 0) {
                std::wstring typeName(typeInfo->TypeName.Buffer, typeInfo->TypeName.Length / sizeof(WCHAR));
                isEvent = (typeName == L"Event");
            }
        }

        // Only ask for the object's NAME if it's an Event - querying names of
        // other object types (e.g. File/pipe handles) can stall, so we avoid it.
        if (isEvent) {
            BYTE nameBuf[0x400];
            ULONG nameLen = 0;
            if (NtQueryObject(hInspect, ObjectNameInformation_Local, nameBuf, sizeof(nameBuf), &nameLen) == 0) {
                auto* nameInfo = reinterpret_cast<OBJECT_NAME_INFORMATION_LOCAL*>(nameBuf);
                if (nameInfo->Name.Buffer && nameInfo->Name.Length > 0) {
                    std::wstring objName(nameInfo->Name.Buffer, nameInfo->Name.Length / sizeof(WCHAR));
                    if (objName.size() >= nameSuffix.size() &&
                        objName.compare(objName.size() - nameSuffix.size(), nameSuffix.size(), nameSuffix) == 0) {
                        HANDLE hCloseDup = NULL;
                        if (DuplicateHandle(hTargetProcess, (HANDLE)entry.HandleValue,
                                             GetCurrentProcess(), &hCloseDup,
                                             0, FALSE, DUPLICATE_CLOSE_SOURCE | DUPLICATE_SAME_ACCESS)) {
                            if (hCloseDup) CloseHandle(hCloseDup);
                            closed = true;
                        }
                    }
                }
            }
        }

        CloseHandle(hInspect);
    }

    CloseHandle(hTargetProcess);
    return closed;
}

// ---------------------------------------------------------------------------
// Tray helpers
// ---------------------------------------------------------------------------
static void ShowBalloon(const wchar_t* title, const wchar_t* text, DWORD flags)
{
    g_nid.uFlags = NIF_INFO;
    wcsncpy_s(g_nid.szInfoTitle, title, _TRUNCATE);
    wcsncpy_s(g_nid.szInfo, text, _TRUNCATE);
    g_nid.dwInfoFlags = flags;
    Shell_NotifyIconW(NIM_MODIFY, &g_nid);
}

static void RegisterForStartup()
{
    wchar_t exePath[MAX_PATH] = {};
    GetModuleFileNameW(NULL, exePath, MAX_PATH);

    HKEY hKey;
    if (RegOpenKeyExW(HKEY_CURRENT_USER,
                       L"Software\\Microsoft\\Windows\\CurrentVersion\\Run",
                       0, KEY_SET_VALUE, &hKey) == ERROR_SUCCESS) {
        RegSetValueExW(hKey, kAppName, 0, REG_SZ,
                       (const BYTE*)exePath,
                       (DWORD)((wcslen(exePath) + 1) * sizeof(wchar_t)));
        RegCloseKey(hKey);
    }
}

static void ShowTrayMenu(HWND hwnd)
{
    HMENU menu = CreatePopupMenu();
    AppendMenuW(menu, MF_STRING | (g_enabled ? MF_CHECKED : MF_UNCHECKED),
                ID_TOGGLE, g_enabled ? L"Enable/Disable checking (ON)" : L"Enable/Disable checking (OFF)");
    AppendMenuW(menu, MF_STRING, ID_EXIT, L"Exit");

    POINT pt;
    GetCursorPos(&pt);
    SetForegroundWindow(hwnd); // required so the menu closes properly on focus loss
    TrackPopupMenu(menu, TPM_RIGHTBUTTON, pt.x, pt.y, 0, hwnd, NULL);
    PostMessage(hwnd, WM_NULL, 0, 0);
    DestroyMenu(menu);
}

// ---------------------------------------------------------------------------
// Core 2-second check
//
// Behavior (by design):
//   - If NO RobloxPlayerBeta.exe is running at all: stay idle, keep polling
//     every 2s for it to appear.
//   - The moment it appears (first instance): don't touch it immediately -
//     Roblox needs a moment to finish creating the singleton Event. Wait
//     ~4 seconds after first detection, then try to close it.
//   - On failure: retry once on the next 2s tick. If that also fails, show
//     a balloon warning and then go quiet until Roblox fully closes.
//   - Success or gave-up-failure: go quiet - do NOT touch it again, even if
//     more Roblox instances are opened afterwards - until every last
//     RobloxPlayerBeta.exe process has closed. Then state resets.
// ---------------------------------------------------------------------------
static void CheckRoblox(HWND hwnd)
{
    if (!g_enabled) return;

    DWORD pid = 0;
    bool running = FindProcessByName(kProcessName, pid);

    if (!running) {
        // Roblox is fully closed - go back to idle, ready for the next launch.
        g_handledThisSession = false;
        g_failCount = 0;
        g_firstDetectedTick = 0;
        return;
    }

    if (g_handledThisSession) {
        // Already dealt with (or already gave up on) this run of Roblox.
        // Leave any other/additional instances alone.
        return;
    }

    if (g_firstDetectedTick == 0) {
        // Just noticed Roblox for the first time this session - start the
        // wait before doing anything to it.
        g_firstDetectedTick = GetTickCount64();
        return;
    }

    if (GetTickCount64() - g_firstDetectedTick < kCloseDelayMs) {
        // Still within the initial wait window - do nothing yet.
        return;
    }

    bool ok = CloseHandleByNameInProcess(pid, kHandleNameSuffix);
    if (ok) {
        g_handledThisSession = true;
        g_failCount = 0;
    } else {
        g_failCount++;
        if (g_failCount >= 2) {
            ShowBalloon(L"MultiRoblox Watcher",
                        L"Couldn't close the ROBLOX singleton handle. A second instance "
                        L"may not start. Try running this app as administrator.",
                        NIIF_WARNING);
            g_handledThisSession = true; // stop trying until Roblox fully closes
            g_failCount = 0;
        }
        // else: leave state as-is so the NEXT 2s tick retries.
    }
}

// ---------------------------------------------------------------------------
// Window procedure
// ---------------------------------------------------------------------------
static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg) {
    case WM_CREATE:
        RegisterForStartup();
        SetTimer(hwnd, ID_TIMER, kCheckIntervalMs, NULL);
        return 0;

    case WM_TIMER:
        if (wParam == ID_TIMER) CheckRoblox(hwnd);
        return 0;

    case WM_TRAYICON:
        if (lParam == WM_LBUTTONUP || lParam == WM_RBUTTONUP) {
            ShowTrayMenu(hwnd);
        }
        return 0;

    case WM_COMMAND:
        switch (LOWORD(wParam)) {
        case ID_TOGGLE:
            g_enabled = !g_enabled;
            g_handledThisSession = false; // re-evaluate current state when re-enabled
            g_failCount = 0;
            g_firstDetectedTick = 0;
            break;
        case ID_EXIT:
            DestroyWindow(hwnd);
            break;
        }
        return 0;

    case WM_DESTROY:
        Shell_NotifyIconW(NIM_DELETE, &g_nid);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------
int APIENTRY wWinMain(HINSTANCE hInstance, HINSTANCE, LPWSTR, int)
{
    // Prevent running two copies of the watcher itself.
    HANDLE singleInstance = CreateMutexW(NULL, TRUE, L"MultiRobloxWatcher_SingleInstanceMutex");
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        return 0;
    }

    WNDCLASSEXW wc = {};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = kWindowClassName;
    RegisterClassExW(&wc);

    // Message-only-style hidden window - we never show it, we only need
    // a HWND to receive tray/timer/menu messages.
    HWND hwnd = CreateWindowExW(0, kWindowClassName, kAppName, 0,
                                 0, 0, 0, 0, HWND_MESSAGE, NULL, hInstance, NULL);
    if (!hwnd) return 1;

    g_nid.cbSize = sizeof(g_nid);
    g_nid.hWnd = hwnd;
    g_nid.uID = 1;
    g_nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    g_nid.uCallbackMessage = WM_TRAYICON;
    g_nid.hIcon = LoadIconW(hInstance, MAKEINTRESOURCEW(IDI_TRAYICON));
    if (!g_nid.hIcon) g_nid.hIcon = LoadIconW(NULL, IDI_APPLICATION); // fallback if resource missing
    wcsncpy_s(g_nid.szTip, L"MultiRoblox Watcher", _TRUNCATE);
    Shell_NotifyIconW(NIM_ADD, &g_nid);

    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    ReleaseMutex(singleInstance);
    CloseHandle(singleInstance);
    return (int)msg.wParam;
}
